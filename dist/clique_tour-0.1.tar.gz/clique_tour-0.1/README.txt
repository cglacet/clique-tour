Build a clique tour for a given number of node n, if n is odd then the tour is eulerian otherwise the tour contains n/2 duplicate edges.
